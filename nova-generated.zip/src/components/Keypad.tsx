import React from 'react';

interface KeypadProps {
  onNumberClick: (num: string) => void;
  onOperatorClick: (op: string) => void;
  onEqualsClick: () => void;
  onClearClick: () => void;
  onDecimalClick: () => void;
  onBackspaceClick: () => void;
}

const Keypad: React.FC<KeypadProps> = ({
  onNumberClick,
  onOperatorClick,
  onEqualsClick,
  onClearClick,
  onDecimalClick,
  onBackspaceClick,
}) => {
  const numbers = ['7', '8', '9', '4', '5', '6', '1', '2', '3', '0'];
  const operators = ['÷', '×', '−', '+'];

  const handleClick = (value: string, type: 'number' | 'operator' | 'function') => {
    if (type === 'number') {
      onNumberClick(value);
    } else if (type === 'operator') {
      onOperatorClick(value);
    }
  };

  return (
    <div className="keypad">
      <div className="keypad-grid">
        <button className="key key-function" onClick={onClearClick} aria-label="Clear">
          C
        </button>
        <button className="key key-function" onClick={onBackspaceClick} aria-label="Backspace">
          ⌫
        </button>
        <button 
          className="key key-operator" 
          onClick={() => handleClick('÷', 'operator')}
          aria-label="Divide"
        >
          ÷
        </button>
        <button 
          className="key key-operator" 
          onClick={() => handleClick('×', 'operator')}
          aria-label="Multiply"
        >
          ×
        </button>

        {numbers.slice(0, 3).map((num) => (
          <button
            key={num}
            className="key key-number"
            onClick={() => handleClick(num, 'number')}
            aria-label={`Number ${num}`}
          >
            {num}
          </button>
        ))}
        <button 
          className="key key-operator" 
          onClick={() => handleClick('−', 'operator')}
          aria-label="Subtract"
        >
          −
        </button>

        {numbers.slice(3, 6).map((num) => (
          <button
            key={num}
            className="key key-number"
            onClick={() => handleClick(num, 'number')}
            aria-label={`Number ${num}`}
          >
            {num}
          </button>
        ))}
        <button 
          className="key key-operator" 
          onClick={() => handleClick('+', 'operator')}
          aria-label="Add"
        >
          +
        </button>

        {numbers.slice(6, 9).map((num) => (
          <button
            key={num}
            className="key key-number"
            onClick={() => handleClick(num, 'number')}
            aria-label={`Number ${num}`}
          >
            {num}
          </button>
        ))}
        <button 
          className="key key-equals" 
          onClick={onEqualsClick}
          aria-label="Equals"
        >
          =
        </button>

        <button
          className="key key-number key-zero"
          onClick={() => handleClick('0', 'number')}
          aria-label="Number 0"
        >
          0
        </button>
        <button 
          className="key key-number" 
          onClick={onDecimalClick}
          aria-label="Decimal point"
        >
          .
        </button>
      </div>
    </div>
  );
};

export default Keypad;