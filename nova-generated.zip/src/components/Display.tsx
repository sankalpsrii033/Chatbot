import React from 'react';

interface DisplayProps {
  value: string;
  expression: string;
  className?: string;
}

const Display: React.FC<DisplayProps> = ({ value, expression, className = '' }) => {
  return (
    <div className={`calculator-display ${className}`}>
      <div className="display-expression" aria-label="Current expression">
        {expression || '\u00A0'}
      </div>
      <div className="display-value" aria-label="Current value" role="status" aria-live="polite">
        {value || '0'}
      </div>
    </div>
  );
};

export default Display;