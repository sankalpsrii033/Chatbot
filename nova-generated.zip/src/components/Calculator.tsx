import React, { useState, useEffect } from 'react';
import Display from './Display';
import Keypad from './Keypad';
import { evaluateExpression, formatNumber } from '../utils/calculatorEngine';
import { addToHistory, getHistory, clearHistory, HistoryEntry } from '../utils/history';
import '../styles/calculator.css';

const Calculator: React.FC = () => {
  const [display, setDisplay] = useState<string>('0');
  const [expression, setExpression] = useState<string>('');
  const [isResult, setIsResult] = useState<boolean>(false);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [showHistory, setShowHistory] = useState<boolean>(false);

  useEffect(() => {
    setHistory(getHistory());
  }, []);

  const handleNumber = (num: string) => {
    if (isResult) {
      setDisplay(num);
      setExpression(num);
      setIsResult(false);
    } else {
      const newDisplay = display === '0' ? num : display + num;
      setDisplay(newDisplay);
      setExpression(expression + num);
    }
  };

  const handleOperator = (operator: string) => {
    if (isResult) {
      setExpression(display + ' ' + operator + ' ');
      setDisplay('0');
      setIsResult(false);
    } else {
      const newExpression = expression + ' ' + operator + ' ';
      setExpression(newExpression);
      setDisplay('0');
    }
  };

  const handleDecimal = () => {
    if (isResult) {
      setDisplay('0.');
      setExpression('0.');
      setIsResult(false);
    } else if (!display.includes('.')) {
      const newDisplay = display + '.';
      setDisplay(newDisplay);
      setExpression(expression + '.');
    }
  };

  const handleEquals = () => {
    if (expression.trim() === '' || isResult) return;

    try {
      const result = evaluateExpression(expression);
      const formattedResult = formatNumber(result);
      
      const entry: HistoryEntry = {
        expression,
        result: formattedResult,
        timestamp: Date.now()
      };
      
      addToHistory(entry);
      setHistory(getHistory());
      
      setDisplay(formattedResult);
      setExpression(formattedResult);
      setIsResult(true);
    } catch (error) {
      setDisplay('Error');
      setExpression('');
      setIsResult(true);
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setExpression('');
    setIsResult(false);
  };

  const handleBackspace = () => {
    if (isResult) {
      handleClear();
      return;
    }

    if (display.length === 1) {
      setDisplay('0');
      setExpression(expression.slice(0, -1));
    } else {
      setDisplay(display.slice(0, -1));
      setExpression(expression.slice(0, -1));
    }
  };

  const handlePercentage = () => {
    try {
      const value = parseFloat(display);
      const result = value / 100;
      const formattedResult = formatNumber(result);
      setDisplay(formattedResult);
      
      if (isResult) {
        setExpression(formattedResult);
      } else {
        const parts = expression.split(/([+\-*/])/);
        parts[parts.length - 1] = formattedResult;
        setExpression(parts.join(''));
      }
    } catch (error) {
      setDisplay('Error');
    }
  };

  const handleToggleSign = () => {
    try {
      const value = parseFloat(display);
      const result = -value;
      const formattedResult = formatNumber(result);
      setDisplay(formattedResult);
      
      if (isResult) {
        setExpression(formattedResult);
      } else {
        const parts = expression.split(/([+\-*/])/);
        parts[parts.length - 1] = formattedResult;
        setExpression(parts.join(''));
      }
    } catch (error) {
      setDisplay('Error');
    }
  };

  const handleHistoryClick = (entry: HistoryEntry) => {
    setDisplay(entry.result);
    setExpression(entry.result);
    setIsResult(true);
    setShowHistory(false);
  };

  const handleClearHistory = () => {
    clearHistory();
    setHistory([]);
  };

  return (
    <div className="calculator-container">
      <div className="calculator">
        <div className="calculator-header">
          <button 
            className="history-toggle"
            onClick={() => setShowHistory(!showHistory)}
            aria-label="Toggle history"
          >
            {showHistory ? '✕' : '🕐'}
          </button>
        </div>

        <Display 
          value={display} 
          expression={expression}
          isResult={isResult}
        />

        <Keypad
          onNumber={handleNumber}
          onOperator={handleOperator}
          onDecimal={handleDecimal}
          onEquals={handleEquals}
          onClear={handleClear}
          onBackspace={handleBackspace}
          onPercentage={handlePercentage}
          onToggleSign={handleToggleSign}
        />
      </div>

      {showHistory && (
        <div className="history-panel">
          <div className="history-header">
            <h3>History</h3>
            {history.length > 0 && (
              <button 
                className="clear-history"
                onClick={handleClearHistory}
              >
                Clear
              </button>
            )}
          </div>
          <div className="history-list">
            {history.length === 0 ? (
              <p className="history-empty">No calculations yet</p>
            ) : (
              history.map((entry, index) => (
                <div 
                  key={entry.timestamp}
                  className="history-item"
                  onClick={() => handleHistoryClick(entry)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      handleHistoryClick(entry);
                    }
                  }}
                >
                  <div className="history-expression">{entry.expression}</div>
                  <div className="history-result">= {entry.result}</div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Calculator;