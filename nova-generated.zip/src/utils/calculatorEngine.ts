export type Operation = '+' | '-' | '*' | '/' | null;

export interface CalculatorState {
  display: string;
  previousValue: number | null;
  operation: Operation;
  waitingForOperand: boolean;
  memory: number;
}

export const initialState: CalculatorState = {
  display: '0',
  previousValue: null,
  operation: null,
  waitingForOperand: false,
  memory: 0,
};

export const inputDigit = (state: CalculatorState, digit: string): CalculatorState => {
  const { display, waitingForOperand } = state;

  if (waitingForOperand) {
    return {
      ...state,
      display: digit,
      waitingForOperand: false,
    };
  }

  return {
    ...state,
    display: display === '0' ? digit : display + digit,
  };
};

export const inputDecimal = (state: CalculatorState): CalculatorState => {
  const { display, waitingForOperand } = state;

  if (waitingForOperand) {
    return {
      ...state,
      display: '0.',
      waitingForOperand: false,
    };
  }

  if (display.indexOf('.') === -1) {
    return {
      ...state,
      display: display + '.',
    };
  }

  return state;
};

export const clear = (): CalculatorState => {
  return { ...initialState };
};

export const clearDisplay = (state: CalculatorState): CalculatorState => {
  return {
    ...state,
    display: '0',
  };
};

export const toggleSign = (state: CalculatorState): CalculatorState => {
  const { display } = state;
  const value = parseFloat(display);

  return {
    ...state,
    display: String(value * -1),
  };
};

export const inputPercent = (state: CalculatorState): CalculatorState => {
  const { display } = state;
  const value = parseFloat(display);

  return {
    ...state,
    display: String(value / 100),
  };
};

const performOperation = (a: number, b: number, operation: Operation): number => {
  switch (operation) {
    case '+':
      return a + b;
    case '-':
      return a - b;
    case '*':
      return a * b;
    case '/':
      if (b === 0) {
        throw new Error('Division by zero');
      }
      return a / b;
    default:
      return b;
  }
};

export const performEquals = (state: CalculatorState): CalculatorState => {
  const { display, previousValue, operation } = state;

  if (operation === null || previousValue === null) {
    return state;
  }

  const currentValue = parseFloat(display);

  try {
    const result = performOperation(previousValue, currentValue, operation);
    const resultString = formatResult(result);

    return {
      ...state,
      display: resultString,
      previousValue: null,
      operation: null,
      waitingForOperand: false,
    };
  } catch (error) {
    return {
      ...state,
      display: 'Error',
      previousValue: null,
      operation: null,
      waitingForOperand: true,
    };
  }
};

export const setOperation = (state: CalculatorState, nextOperation: Operation): CalculatorState => {
  const { display, previousValue, operation } = state;
  const currentValue = parseFloat(display);

  if (previousValue === null) {
    return {
      ...state,
      previousValue: currentValue,
      operation: nextOperation,
      waitingForOperand: true,
    };
  }

  if (operation !== null && !state.waitingForOperand) {
    try {
      const result = performOperation(previousValue, currentValue, operation);
      const resultString = formatResult(result);

      return {
        ...state,
        display: resultString,
        previousValue: result,
        operation: nextOperation,
        waitingForOperand: true,
      };
    } catch (error) {
      return {
        ...state,
        display: 'Error',
        previousValue: null,
        operation: null,
        waitingForOperand: true,
      };
    }
  }

  return {
    ...state,
    operation: nextOperation,
    waitingForOperand: true,
  };
};

export const backspace = (state: CalculatorState): CalculatorState => {
  const { display, waitingForOperand } = state;

  if (waitingForOperand) {
    return state;
  }

  if (display.length > 1) {
    return {
      ...state,
      display: display.slice(0, -1),
    };
  }

  return {
    ...state,
    display: '0',
  };
};

const formatResult = (value: number): string => {
  const MAX_DIGITS = 12;
  
  if (!isFinite(value)) {
    return 'Error';
  }

  let result = String(value);

  if (result.length > MAX_DIGITS) {
    if (Math.abs(value) < 1e-6 || Math.abs(value) > 1e12) {
      result = value.toExponential(6);
    } else {
      const decimalIndex = result.indexOf('.');
      if (decimalIndex !== -1) {
        const integerPart = result.slice(0, decimalIndex);
        const remainingDigits = MAX_DIGITS - integerPart.length - 1;
        result = value.toFixed(Math.max(0, remainingDigits));
      }
    }
  }

  result = result.replace(/\.?0+$/, '');

  return result;
};

export const getDisplayExpression = (state: CalculatorState): string => {
  const { previousValue, operation, display } = state;

  if (previousValue !== null && operation !== null) {
    return `${previousValue} ${operation} ${display}`;
  }

  return display;
};

export const memoryStore = (state: CalculatorState): CalculatorState => {
  const value = parseFloat(state.display);
  return {
    ...state,
    memory: value,
  };
};

export const memoryRecall = (state: CalculatorState): CalculatorState => {
  return {
    ...state,
    display: String(state.memory),
    waitingForOperand: false,
  };
};

export const memoryClear = (state: CalculatorState): CalculatorState => {
  return {
    ...state,
    memory: 0,
  };
};

export const memoryAdd = (state: CalculatorState): CalculatorState => {
  const value = parseFloat(state.display);
  return {
    ...state,
    memory: state.memory + value,
  };
};

export const memorySubtract = (state: CalculatorState): CalculatorState => {
  const value = parseFloat(state.display);
  return {
    ...state,
    memory: state.memory - value,
  };
};