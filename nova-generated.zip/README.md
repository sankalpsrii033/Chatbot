# Calculator

A modern, responsive calculator application built with React and TypeScript. Features basic arithmetic operations, calculation history, and a clean interface that works seamlessly on both desktop and mobile devices.

## Features

- **Basic Arithmetic Operations**: Addition, subtraction, multiplication, and division
- **Responsive Design**: Optimized for both desktop and mobile screens
- **Calculation History**: Track and review previous calculations
- **Keyboard Support**: Use your keyboard for faster input on desktop
- **Clean UI**: Minimal, intuitive interface focused on usability

## Tech Stack

- React 18
- TypeScript
- Vite
- CSS3

## Getting Started

### Prerequisites

- Node.js 16+ 
- npm or yarn

### Installation

```bash
# Clone the repository
git clone <repository-url>
cd calculator

# Install dependencies
npm install

# Start development server
npm run dev
```

The application will be available at `http://localhost:5173`

### Build for Production

```bash
npm run build
```

The optimized build will be in the `dist` directory.

## Usage

### Mouse/Touch Input
- Click or tap buttons to perform calculations
- Use the display to see your current input and results
- Access history to view previous calculations

### Keyboard Input (Desktop)
- **Numbers**: 0-9
- **Operators**: +, -, *, /
- **Enter/=**: Calculate result
- **Escape/C**: Clear current input
- **Backspace**: Delete last character

## Project Structure

```
src/
├── components/
│   ├── Calculator.tsx      # Main calculator container
│   ├── Display.tsx          # Display component
│   └── Keypad.tsx           # Button grid component
├── utils/
│   ├── calculatorEngine.ts # Calculation logic
│   └── history.ts           # History management
├── styles/
│   └── calculator.css       # Styling
└── App.tsx                  # Root component
```

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Android)

## License

MIT